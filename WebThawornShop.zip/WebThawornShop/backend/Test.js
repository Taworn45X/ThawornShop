const bcrypt = require('bcrypt');

const password = '1234'; // รหัสผ่านที่ใช้ในการทดสอบ
const saltRounds = 10;

// การเข้ารหัสรหัสผ่าน
bcrypt.hash(password, saltRounds, (err, hashedPassword) => {
    if (err) {
        console.error('Error hashing password:', err);
        return;
    }
    console.log('Hashed Password:', hashedPassword);

    // การเปรียบเทียบรหัสผ่าน
    bcrypt.compare(password, hashedPassword, (err, result) => {
        if (err) {
            console.error('Error comparing passwords:', err);
            return;
        }
        console.log('Password match:', result); // ควรเป็น true
    });
});