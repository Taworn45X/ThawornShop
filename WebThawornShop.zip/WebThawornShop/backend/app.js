const express = require('express');
const mysql = require('mysql2');
const path = require('path');
const bcrypt = require('bcrypt');
const session = require('express-session'); // ใช้สำหรับการจัดการเซสชัน

const app = express();
const port = 3000;
const saltRounds = 10;

// สร้างการเชื่อมต่อฐานข้อมูล
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '', // ใส่รหัสผ่านที่คุณตั้งไว้
    database: 'mydatabase', // เปลี่ยนชื่อฐานข้อมูลตามที่คุณใช้
    port: 3306
});

// เชื่อมต่อฐานข้อมูล
connection.connect(err => {
    if (err) {
        console.error('การเชื่อมต่อล้มเหลว:', err.stack);
        return;
    }
    console.log('เชื่อมต่อฐานข้อมูลเรียบร้อย');
});

// ตั้งค่าให้ใช้ JSON
app.use(express.json());

// ตั้งค่าเซสชัน
app.use(session({
    secret: 'your_secret_key', // ใช้สำหรับการเข้ารหัสเซสชัน
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false } // ใช้ `secure: true` ถ้าใช้ HTTPS
}));

// ให้บริการไฟล์ static จากโฟลเดอร์ frontend
app.use(express.static(path.join('D:/WebThawornShop/frontend')));

// เพิ่ม route สำหรับหน้าแรก
app.get('/', (req, res) => {
    res.sendFile(path.join('D:/WebThawornShop/frontend/index.html'));
});

// สร้าง route สำหรับดึงข้อมูลผู้ใช้
app.get('/users', (req, res) => {
    connection.query('SELECT id, username FROM users', (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(results);
    });
});

// Route สำหรับสมัครสมาชิก
app.post('/register', (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ error: 'Username and password are required' });
    }

    bcrypt.hash(password, saltRounds, (err, hashedPassword) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        const query = 'INSERT INTO users (username, password) VALUES (?, ?)';
        connection.query(query, [username, hashedPassword], (err, results) => {
            if (err) {
                return res.status(500).json({ error: err.message });
            }
            res.status(201).json({ id: results.insertId, username });
        });
    });
});

app.post('/login', (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) {
        return res.status(400).json({ error: 'Username and password are required' });
    }

    const query = 'SELECT * FROM users WHERE username = ?';
    connection.query(query, [username], (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        if (results.length > 0) {
            const user = results[0];
            console.log('Stored hashed password:', user.password); // ตรวจสอบค่าที่เก็บในฐานข้อมูล
            bcrypt.compare(password, user.password, (err, result) => {
                if (err) {
                    return res.status(500).json({ error: err.message });
                }

                console.log('Password match result:', result); // ตรวจสอบผลการเปรียบเทียบ
                if (result) {
                    req.session.user = user; // เก็บข้อมูลผู้ใช้ในเซสชัน
                    const updateQuery = 'UPDATE users SET last_login = NOW() WHERE username = ?';
                    connection.query(updateQuery, [username], (updateErr) => {
                        if (updateErr) {
                            return res.status(500).json({ error: updateErr.message });
                        }
                        res.json({ message: 'Login successful', user });
                    });
                } else {
                    res.status(401).json({ error: 'Invalid credentials' });
                }
            });
        } else {
            res.status(401).json({ error: 'Invalid credentials' });
        }
    });
});




// Route สำหรับออกจากระบบ
app.post('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            return res.status(500).json({ error: 'Failed to log out' });
        }
        res.json({ message: 'Logged out successfully' });
    });
});

// เริ่มเซิร์ฟเวอร์
app.listen(port, () => {
    console.log(`เซิร์ฟเวอร์ทำงานที่ http://localhost:${port}`);
});
